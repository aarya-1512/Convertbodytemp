def celsius_to_fahrenheit(celsius):
    return (celsius * 9/5) + 32

def fahrenheit_to_celsius(fahrenheit):
    return (fahrenheit - 32) * 5/9


def temperature_conversion():
    print("Choose the conversion direction:")
    print("C - Celsius to Fahrenheit")
    print("F - Fahrenheit to Celsius")
    
    choice = input("Enter your choice: ").strip().upper()
    
    if choice == 'C':
        celsius = float(input("Enter the temperature in Celsius: "))
        fahrenheit = celsius_to_fahrenheit(celsius)
        print(f"{celsius} degrees Celsius is equal to {fahrenheit:.1f} degrees Fahrenheit.")
    
    elif choice == 'F':
        fahrenheit = float(input("Enter the temperature in Fahrenheit: "))
        celsius = fahrenheit_to_celsius(fahrenheit)
        print(f"{fahrenheit} degrees Fahrenheit is equal to {celsius:.1f} degrees Celsius.")
    
    else:
        print("Invalid choice. Please enter 'C' for Celsius to Fahrenheit or 'F' for Fahrenheit to Celsius.")

temperature_conversion()
